# Dread Forge
Horror short factory: idea → hook → story → scenes → voice + FX rack → captions → retention score → export.
## Run
`npm install && npm run dev` (Chrome or Edge recommended). `npm run build` type-checks and builds.
## Architecture
`features/stories` (generator, Hook Lab), `features/voice` (Web Audio engine, FX rack, recording), `features/editor` (canvas renderer, scenes, look panel), `features/analytics` (heuristic scoring), `features/export` (MediaRecorder), `lib/db.ts` (IndexedDB), `data/catalog.ts` (genres, faces, templates: extend here).
## Demo implementation vs production integration
| Area | Demo (works now) | Production hook |
|---|---|---|
| Stories, hooks, content pack | deterministic local templates (`stories/forge.ts`) | replace `hooks()/story()` with a call to your backend |
| TTS | browser SpeechSynthesis preview only | add a `TTSProvider` behind your backend (ElevenLabs/OpenAI/Azure); never put API keys in the client |
| Scoring | heuristics, labeled as estimates | none; cannot predict real platform performance |
| Export | MediaRecorder: MP4 if the browser allows, else WebM | add FFmpeg/WASM transcode in `features/export` |
| Assets | procedural visuals, generated audio FX | connect a licensed asset library; never scrape copyrighted media |
## Security
No keys in source. Uploads are validated (audio type, 25 MB cap). Project import is size-limited and shape-checked.
## Not built yet
Multi-track timeline with trim/split/keyframes, sound-effect library, music with ducking, cover generator, silence trimming, command palette, line-by-line recording, Web Worker offload.
## Android APK
Easiest: push this folder to a new GitHub repo, open Actions, run "Build Android APK", download the `dread-forge-apk` artifact, copy `app-debug.apk` to your phone and install it (allow "install unknown apps").
Local: install Android Studio + JDK 17, then `npm run build && npx cap add android`, add RECORD_AUDIO and MODIFY_AUDIO_SETTINGS permissions to AndroidManifest.xml, `npx cap sync android`, `npx cap open android`, and press Run.
Exports on the phone open the Android share sheet (save to Files, or send straight to apps). The APK is a debug build; sign a release build before publishing to Play.
