import type {CapacitorConfig} from '@capacitor/cli';
const config:CapacitorConfig={appId:'com.dreadforge.app',appName:'Dread Forge',webDir:'dist',android:{allowMixedContent:false}};export default config;
