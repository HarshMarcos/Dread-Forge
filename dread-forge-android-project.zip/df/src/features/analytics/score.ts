// Heuristic estimates only. They are not predictions of real platform performance.
import type {Project} from '../../types';import {scenes} from '../editor/render';
const wc=(s:string)=>s.split(/\s+/).filter(Boolean).length,cl=(n:number)=>Math.max(0,Math.min(100,Math.round(n)));
export function analyze(p:Project){const sc=scenes(p),L=sc.map(s=>s.t),hw=wc(p.hook),all=L.join(' '),avg=L.length?wc(all)/L.length:0,dur=wc(all)/2.4+2;
 const hook=cl(60+(hw<=11?15:-10)+(/\d|never|nobody|rule|not|last|only/i.test(p.hook)?15:0)+(/\?|\.\.\./.test(p.hook)?5:0)),
 cur=cl(45+(/why|who|what|never|nobody|sealed|deleted|exactly/i.test(p.hook+all)?25:0)+(L.length>=5?15:0)),
 pacing=cl(100-Math.abs(avg-8)*6-(dur>45?15:0)-(L.length<4?20:0)),
 twist=cl(40+(/realized|inside|mine|already|worse|smiling/i.test(L.slice(-3).join(' '))?35:0)+(L.length>5?10:0)),
 cta=cl(35+(/\?/.test(p.cta)?30:0)+(/comment|part 2|follow/i.test(p.cta)?25:0)),
 vis=cl(50+Object.values(p.vfx).reduce((a,b)=>a+b,0)*8+(p.vfx.interrupt>0?15:0)),cap=cl(90-Math.max(0,avg-10)*8+(p.caption=='viral'||p.caption=='karaoke'?8:0)),
 rep=cl(40+(p.loop?40:0)+(twist>70?10:0)),total=cl(hook*.25+cur*.15+pacing*.15+twist*.12+cta*.08+vis*.08+cap*.07+rep*.1);
 const tips:{t:string;fix?:string}[]=[];
 if(hw>11)tips.push({t:'Your hook is long. Cut it to 11 words or fewer.',fix:'shortHook'});
 if(cta<65)tips.push({t:'End on an open question so people comment.',fix:'cta'});
 if(!p.loop)tips.push({t:'Turn on the loop ending so the last line leads back into the hook.',fix:'loop'});
 if(!(p.vfx.interrupt>0))tips.push({t:'Add pattern interrupts so attention does not sag mid-video.',fix:'interrupt'});
 if(avg>11)tips.push({t:'Beats are long. Split lines so captions stay readable.'});
 if(!tips.length)tips.push({t:'Solid structure. Test two hooks and compare real retention.'});
 const curve=sc.map((s,i)=>cl(i==0?90:55+(i/Math.max(1,sc.length-1))*30+(p.vfx.interrupt>0?8:0)-(s.t.length>70?25:0)));
 return {total,parts:{Hook:hook,Curiosity:cur,Pacing:pacing,Twist:twist,CTA:cta,Visual:vis,Captions:cap,Replay:rep},tips,curve,dur}}
