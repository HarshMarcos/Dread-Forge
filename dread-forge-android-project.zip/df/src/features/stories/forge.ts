// DEMO IMPLEMENTATION: deterministic local generator. PRODUCTION: swap hooks()/story() for a backend call.
import type {Controls,Project} from '../../types';
const hash=(s:string)=>[...s].reduce((a,c)=>(a*31+c.charCodeAt(0))|0,7);const pick=<T,>(a:T[],s:number,o=0)=>a[Math.abs(s+o*7919)%a.length];
const sub=(i:string)=>i.replace(/^(a|an|the|someone|something)\s+/i,'').replace(/[.!?]+$/,'').trim()||'the door';
const up=(s:string)=>s[0].toUpperCase()+s.slice(1);
export const HOOK_STRATEGIES:Record<string,((s:string)=>string)[]>={
 Curiosity:[s=>`Nobody explained why ${s}.`,s=>`I only found out the real reason for ${s} last night.`],Fear:[s=>`I should never have ignored ${s}.`,s=>`Whatever you do, do not ignore ${s}.`],
 Shock:[s=>`They found my notes about ${s}. Then they found me.`,s=>`${up(s)}. That was the last normal thing.`],Mystery:[s=>`The footage of ${s} was deleted. I kept a copy.`,s=>`Three people reported ${s}. All described the same face.`],
 Impossible:[s=>`${up(s)} is impossible. I live on the 9th floor.`],Countdown:[s=>`At exactly 3:07 AM: ${s}.`,s=>`I have 3 minutes before ${s} starts again.`],
 Rule:[s=>`There is one rule about ${s}. You cannot break it.`,s=>`Rule 4 about ${s}: never answer.`],Confession:[s=>`I never told anyone about ${s}.`],Warning:[s=>`If you notice ${s}, do not look up.`],
 POV:[s=>`POV: ${s} and you are alone.`],Question:[s=>`Why does ${s} only happen when I am alone?`],Unexplained:[s=>`Police logged ${s}. The report was sealed.`]};
export function hooks(idea:string,n=10){const s=sub(idea),h=hash(idea),out:{cat:string;text:string}[]=[],cats=Object.keys(HOOK_STRATEGIES);
 for(let i=0;out.length<n&&i<60;i++){const c=cats[(i+Math.abs(h))%cats.length],t=pick(HOOK_STRATEGIES[c],h,i)(s);if(!out.find(o=>o.text==t))out.push({cat:c,text:t})}return out}
export function story(idea:string,c:Controls,genre='Psychological horror'){const s=sub(idea),h=hash(idea+genre),H=hooks(idea,12),hook=H[Math.abs(h)%H.length].text,sc=c.scary>60;
 const esc=[`Then it happened again, closer.`,sc?`The air felt heavier. Something was learning my routine.`:`It repeated, and this time I wrote down the time.`,c.realism>60?`I checked the logs. Nothing explained it.`:`The lights dimmed as if listening.`];
 const lines=[`It started like any other night.`,`I noticed it because of ${s}.`,...esc.slice(0,2+(c.mystery>50?1:0)),c.twist>60?`That is when I realized the sound was coming from inside.`:`I finally looked, and there was nothing there. That was worse.`,`The timestamp matched the first night. Exactly.`,sc?`It knows I know.`:`If you hear it too, do not answer.`];
 return {hook,lines,cta:pick(['Part 2? Comment A or B','Would you have opened it? Comment below','Did you hear it too?','Follow for the next recording'],h),genre}}
export const rewrite={disturb:(L:string[])=>L.map((t,i)=>i==L.length-1?t.replace(/\.$/,'. It was smiling.'):t.replace(/nothing/g,'no one')),
 real:(L:string[])=>L.map((t,i)=>i==0?`Case file ${Math.abs(hash(t))%900+100}: ${t}`:t),twist:(L:string[])=>[...L.slice(0,-1),'The voice on the recording was mine.',L[L.length-1]],
 viral:(L:string[])=>L.map((l,i)=>i==L.length-1?l.replace(/\.$/,'... why?'):l.length>70?l.split(',')[0]+'.':l)};
export function pack(p:Project){const t=p.hook.replace(/[.]$/,''),tags=['#horror','#scarystories','#creepy','#mystery','#shorts',`#${p.genre.split(' ')[0].toLowerCase()}`];
 return {Title:t.slice(0,60),'Thumbnail text':t.split(' ').slice(0,4).join(' ').toUpperCase(),Description:`${t}. Original fiction. ${p.cta}`,'Shorts caption':`${t} #shorts #horror`,'TikTok caption':`${t} ${tags.join(' ')}`,'Reels caption':`${p.hook}\n${tags.join(' ')}\nFiction.`,'Pinned comment':p.cta,Hashtags:tags.join(' ')}}
