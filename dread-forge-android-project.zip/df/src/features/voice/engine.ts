import type {Num} from '../../types';
export const DEFAULT_FX:Num={pitch:1,eq:0,drive:.3,ring:50,echo:.3,reverb:.3};
export const MODS=[['pitch','Pitch / speed',.5,1.6,.01],['eq','Low boost (dB)',-12,14,1],['drive','Distortion',0,1,.05],['ring','Ring mod (Hz)',10,400,5],['echo','Echo mix',0,.8,.05],['reverb','Reverb mix',0,.9,.05]] as const;
const P=(fx:Num,on:string)=>({fx:{...DEFAULT_FX,...fx},on:Object.fromEntries(on.split(' ').filter(Boolean).map(k=>[k,true]))});
export const PRESETS:Record<string,{fx:Num;on:Record<string,boolean>}>={Natural:P({},''),Whisper:P({pitch:1.05,eq:-8,reverb:.5},'pitch eq reverb'),'Deep horror':P({pitch:.78,eq:8,reverb:.4},'pitch eq reverb'),Demon:P({pitch:.68,eq:10,drive:.5,reverb:.35},'pitch eq drive reverb'),
 Possessed:P({pitch:.82,ring:28,drive:.4,reverb:.5},'pitch drive ring reverb'),Ghost:P({pitch:.93,echo:.55,reverb:.8},'pitch echo reverb'),Radio:P({eq:-10,drive:.7},'eq drive'),Robot:P({ring:55,drive:.2},'ring drive'),Alien:P({pitch:1.2,ring:320},'pitch ring reverb'),
 Giant:P({pitch:.55,reverb:.6},'pitch reverb'),Cave:P({echo:.5,reverb:.9},'echo reverb'),Glitch:P({ring:12,drive:.9,echo:.4},'ring drive echo'),Childlike:P({pitch:1.4},'pitch')};
function impulse(c:AudioContext,s:number){const L=c.sampleRate*s|0,b=c.createBuffer(2,L,c.sampleRate);for(let h=0;h<2;h++){const d=b.getChannelData(h);for(let i=0;i<L;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/L,2.5)}return b}
export class Engine{ac!:AudioContext;an!:AnalyserNode;rd!:MediaStreamAudioDestinationNode;el:HTMLAudioElement|null=null;src:MediaElementAudioSourceNode|null=null;tail:AudioNode|null=null;stops:(()=>void)[]=[];
 run=false;t0=0;last=0;onEnd=()=>{};bypass=false;recDur=0;
 init(){if(this.ac)return;this.ac=new AudioContext();this.an=this.ac.createAnalyser();this.an.fftSize=1024;this.rd=this.ac.createMediaStreamDestination();this.an.connect(this.ac.destination);this.an.connect(this.rd)}
 load(b:Blob,dur=0){this.init();this.el?.pause();this.recDur=dur;this.el=new Audio(URL.createObjectURL(b));this.src=this.ac.createMediaElementSource(this.el);this.el.onended=()=>this.finish()}
 apply(fx:Num,on:Record<string,boolean>){if(!this.src||!this.el)return;const c=this.ac,e=this.el;this.stops.forEach(f=>f());this.stops=[];try{this.src.disconnect()}catch{}try{this.tail?.disconnect()}catch{}
  const live=!this.bypass;e.preservesPitch=false;e.playbackRate=live&&on.pitch?fx.pitch:1;let n:AudioNode=this.src;const to=(x:AudioNode)=>{n.connect(x);n=x};
  if(live&&on.eq){const f=c.createBiquadFilter();f.type='lowshelf';f.frequency.value=220;f.gain.value=fx.eq;to(f)}
  if(live&&on.drive){const w=c.createWaveShaper(),k=fx.drive*40+1,a=new Float32Array(1024);for(let i=0;i<1024;i++){const v=i/512-1;a[i]=(1+k)*v/(1+k*Math.abs(v))}w.curve=a;to(w)}
  if(live&&on.ring){const g=c.createGain(),o=c.createOscillator();g.gain.value=0;o.frequency.value=fx.ring;o.connect(g.gain);o.start();this.stops.push(()=>o.stop());to(g)}
  if(live&&on.echo){const d=c.createDelay(2),f=c.createGain(),w=c.createGain(),o=c.createGain();d.delayTime.value=.32;f.gain.value=.45;w.gain.value=fx.echo;n.connect(o);n.connect(d);d.connect(f);f.connect(d);d.connect(w);w.connect(o);n=o}
  if(live&&on.reverb){const v=c.createConvolver();v.buffer=impulse(c,2.5);const w=c.createGain(),o=c.createGain();w.gain.value=fx.reverb;n.connect(o);n.connect(v);v.connect(w);w.connect(o);n=o}
  const lim=c.createDynamicsCompressor();lim.threshold.value=-6;lim.ratio.value=20;to(lim);const g=c.createGain();g.gain.value=live&&Object.values(on).some(Boolean)?1.4:1;to(g);g.connect(this.an);this.tail=g}
 get dur(){const d=this.el?(isFinite(this.el.duration)?this.el.duration:this.recDur):0;return d}
 start(est:number){this.init();this.ac.resume();this.run=true;this.t0=performance.now();this.last=0;this.est=est;if(this.el){this.el.currentTime=0;this.el.play()}}
 est=10;stop(){this.run=false;this.el?.pause()}finish(){setTimeout(()=>{const was=this.run;this.stop();this.last=0;if(was)this.onEnd()},600)}
 prog(){if(!this.run)return this.last;const p=this.el?this.el.currentTime/Math.max(.1,this.dur):(performance.now()-this.t0)/1000/this.est;if(!this.el&&p>=1){this.last=1;this.finish()}return this.last=Math.min(1,p)}
 level(){if(!this.an)return 0;const d=new Uint8Array(this.an.frequencyBinCount);this.an.getByteFrequencyData(d);let s=0;for(let i=2;i<40;i++)s+=d[i];return s/38/255}
 total(est:number,rate:number){return this.el?this.dur/rate:est}}
export async function recordMic(onStop:(b:Blob,dur:number)=>void){const s=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true}}),m=new MediaRecorder(s),ch:Blob[]=[],t=performance.now();
 m.ondataavailable=e=>ch.push(e.data);m.onstop=()=>{s.getTracks().forEach(x=>x.stop());onStop(new Blob(ch,{type:m.mimeType}),(performance.now()-t)/1000)};m.start();return m}
export function validateAudio(f:File){if(!f.type.startsWith('audio/'))return'That file is not audio.';if(f.size>25*1024*1024)return'Audio is over 25 MB. Trim it first.';return''}
