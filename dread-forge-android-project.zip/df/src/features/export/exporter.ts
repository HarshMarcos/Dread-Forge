import type {Engine} from '../voice/engine';
// Browser MediaRecorder export. MP4 only where the browser supports it; otherwise WebM.
// PRODUCTION: add an FFmpeg/WASM transcode step (e.g. @ffmpeg/ffmpeg) to convert WebM to MP4 for every browser.
export const pickMime=()=>['video/mp4;codecs=avc1,mp4a.40.2','video/webm;codecs=vp9,opus','video/webm'].find(t=>typeof MediaRecorder!=='undefined'&&MediaRecorder.isTypeSupported(t))||'';
export function startExport(cv:HTMLCanvasElement,e:Engine,fps:number,audio:boolean,done:(b:Blob,ext:string)=>void){e.init();const st=cv.captureStream(fps);if(audio)e.rd.stream.getAudioTracks().forEach(t=>st.addTrack(t));
 const mime=pickMime(),m=new MediaRecorder(st,mime?{mimeType:mime,videoBitsPerSecond:8e6}:{}),ch:Blob[]=[];m.ondataavailable=ev=>ev.data.size&&ch.push(ev.data);
 m.onstop=()=>done(new Blob(ch,{type:m.mimeType}),(m.mimeType||'').includes('mp4')?'mp4':'webm');m.start(250);return m}
