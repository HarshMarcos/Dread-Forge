import type {Project} from '../../types';
export interface Sc{i:number;t:string;a:number;b:number;stage:string}
const ST=['HOOK','SETUP','ESCALATION','REVEAL','PAYOFF'];
export function scenes(p:Project):Sc[]{const L=p.script.split('\n').map(s=>s.trim()).filter(Boolean),w=L.map(l=>l.length+10),s=w.reduce((a,b)=>a+b,0)||1;let c=0;
 return L.map((t,i)=>{const a=.04+c/s*.88;c+=w[i];return{i,t,a,b:.04+c/s*.88,stage:ST[Math.min(4,Math.floor(i/L.length*5))]}})}
export function dims(f:string,res:number){const[a,b]=f.split(':').map(Number);return a<=b?{w:res,h:Math.round(res*b/a)}:{w:Math.round(res*a/b),h:res}}
const el=(x:CanvasRenderingContext2D,a:number,b:number,rx:number,ry:number,f:string|CanvasGradient,r=0)=>{x.beginPath();x.ellipse(a,b,Math.max(.1,rx),Math.max(.1,ry),r,0,7);x.fillStyle=f;x.fill()};
const teeth=(x:CanvasRenderingContext2D,y:number,wd:number,n:number,len:number,dir:number,f:string)=>{x.fillStyle=f;for(let i=0;i<n;i++){const a=-wd+2*wd*(i+.5)/n,s=wd/n*.45;x.beginPath();x.moveTo(a-s,y);x.lineTo(a+s,y);x.lineTo(a,y+len*dir);x.fill()}};
const COL:Record<string,[string,string]>={shadow:['#1a1a22','#000'],hollow:['#f2efe2','#7d7a68'],smiler:['#efe9d8','#9d977f'],demon:['#7a1410','#1a0403'],pale:['#dcdad6','#8b8a8c'],faceless:['#c9b9a6','#7a6a5a']};
const DEF:Record<string,[string,string]>={shadow:['glow','none'],hollow:['empty','open'],smiler:['dot','smile'],demon:['red','open'],pale:['dot','line'],faceless:['none','none']};
function entity(x:CanvasRenderingContext2D,p:Project,cx:number,cy:number,s:number,m:number,T:number){
 x.save();x.translate(cx,cy);x.rotate(Math.sin(T*.0007)*.025);const k=1+Math.sin(T*.0012)*.012;x.scale(k,k);const w=s*.42,h=s*(p.face=='pale'?.7:.6),[c1,c2]=COL[p.face]||COL.hollow,g=x.createRadialGradient(-w*.2,-h*.3,10,0,0,h);g.addColorStop(0,c1);g.addColorStop(1,c2);
 const glow=p.face=='demon'?'#f33':p.face=='shadow'?'#9bf':'#e8e0c8';x.shadowColor=glow;x.shadowBlur=40;
 if(p.face=='demon'){x.fillStyle='#240806';for(const q of[-1,1]){x.beginPath();x.moveTo(q*w*.4,-h*.8);x.lineTo(q*w*.85,-h*1.3);x.lineTo(q*w*.78,-h*.5);x.fill()}}
 el(x,0,0,w*(p.face=='pale'?.72:.88),h*.95,g);x.shadowBlur=0;const d=DEF[p.face]||DEF.hollow,eyes=p.eyes=='auto'?d[0]:p.eyes,mo=p.mouth=='auto'?d[1]:p.mouth,bl=Math.sin(T*.003)>.96?.12:1,ey=-h*.18;
 for(const q of[-1,1]){const ex=q*w*.34+Math.sin(T*.0017)*5;
  if(eyes=='dot')el(x,ex,ey,w*.05,w*.07*bl,'#000');else if(eyes=='empty'){el(x,ex,ey,w*.26,h*.18*bl,'#000',q*.15)}
  else if(eyes=='red'){x.shadowColor='#f22';x.shadowBlur=30;el(x,ex,ey,w*.17,h*.05*bl+1,'#ff2a2a',-q*.3);x.shadowBlur=0}
  else if(eyes=='glow'){x.shadowColor='#cdf';x.shadowBlur=25;el(x,ex,ey,w*.1,w*.13*bl,'#f4f8ff');x.shadowBlur=0}}
 const y=h*.46,o=m*h*.28;
 if(mo=='smile'){x.beginPath();x.moveTo(-w*.75,y-h*.35);x.quadraticCurveTo(0,y+h*.2+o,w*.75,y-h*.35);x.quadraticCurveTo(0,y-h*.2,-w*.75,y-h*.35);x.fillStyle='#050000';x.fill();x.save();x.clip();x.fillStyle='#f2efe0';x.fillRect(-w,y-h*.37,2*w,h*.14);x.restore()}
 else if(mo=='open'){el(x,0,y+o*.4,w*.5,h*.03+o*.5,'#000');teeth(x,y-h*.02,w*.46,7,h*.08,1,'#eee');teeth(x,y+o*.9,w*.46,6,h*.07,-1,'#ddd')}
 else if(mo=='line'){x.fillStyle='#000';x.fillRect(-w*.25,y,w*.5,2+o*.5)}
 x.restore()}
function bg(x:CanvasRenderingContext2D,W:number,H:number,T:number,v:string){const g=x.createRadialGradient(W/2,H*.4,10,W/2,H*.4,Math.max(W,H)*.7);g.addColorStop(0,v=='cctv'?'#14231a':v=='static'?'#1d1d22':'#1d1229');g.addColorStop(1,'#000');x.fillStyle=g;x.fillRect(0,0,W,H);x.strokeStyle='rgba(255,255,255,.07)';x.lineWidth=2;
 if(v=='hallway'){for(let i=-6;i<=6;i++){x.beginPath();x.moveTo(W/2+i*8,H*.4);x.lineTo(W/2+i*W*.25,H);x.stroke();x.beginPath();x.moveTo(W/2+i*8,H*.4);x.lineTo(W/2+i*W*.25,0);x.stroke()}}
 else if(v=='forest'){for(let i=0;i<14;i++){const px=(i*97%W)+Math.sin(T*.0003+i)*6;x.fillStyle='rgba(8,14,10,.9)';x.fillRect(px,0,10+i%4*10,H)}}
 else if(v=='static'){for(let i=0;i<260;i++){x.fillStyle=`rgba(255,255,255,${Math.random()*.3})`;x.fillRect(Math.random()*W,Math.random()*H,3,2)}}}
function words(x:CanvasRenderingContext2D,t:string,mx:number){const o:string[]=[];let l='';t.split(' ').forEach(w=>{const q=l?l+' '+w:w;if(x.measureText(q).width>mx&&l){o.push(l);l=w}else l=q});o.push(l);return o}
function caption(x:CanvasRenderingContext2D,W:number,H:number,b:Sc,p:number,pr:Project,u:number){const q=Math.max(0,Math.min(.999,(p-b.a)/(b.b-b.a))),fs=62*u,mono=pr.caption=='typewriter'||pr.caption=='vhs'||pr.caption=='alert';
 x.font=(mono?'700 ':'900 ')+fs*(mono?.8:1)+'px '+(mono?'"Courier New",monospace':'Impact,"Arial Black",sans-serif');x.lineJoin='round';x.lineWidth=fs*.2;x.textAlign='left';
 let txt=b.t;if(pr.caption=='typewriter')txt=b.t.slice(0,Math.ceil(q*1.4*b.t.length));
 const ws=txt.split(' '),hi=Math.floor(q*b.t.split(' ').length),L=words(x,txt,W*.78),y0=H*(pr.fmt=='16:9'?.82:.7);let wi=0;
 if(pr.caption=='alert'){x.fillStyle='rgba(0,0,0,.65)';x.fillRect(W*.07,y0-fs*1.2,W*.86,fs*(L.length*1.2+.6))}
 L.forEach((ln,i)=>{const yy=y0+(i-(L.length-1)/2)*fs*1.2,tw=x.measureText(ln).width;let px=W/2-tw/2;for(const w of ln.split(' ')){const ww=x.measureText(w+' ').width,cur=pr.caption=='karaoke'?wi<=hi:wi==hi;
  if(pr.caption=='vhs'){x.fillStyle='rgba(255,0,60,.7)';x.fillText(w,px-3*u,yy);x.fillStyle='rgba(0,200,255,.7)';x.fillText(w,px+3*u,yy)}else{x.strokeStyle='#000';x.strokeText(w,px,yy)}
  x.fillStyle=pr.caption=='karaoke'?(cur?'#e0a43a':'#cfc6d8'):pr.caption=='viral'&&cur?'#e0a43a':'#fff';x.fillText(w,px,yy);px+=ww;wi++}});void ws}
export function render(x:CanvasRenderingContext2D,W:number,H:number,p:number,T:number,pr:Project,sc:Sc[],lvl:number,total:number){
 const u=Math.min(W,H)/720,v=pr.vfx,rt=p*total,cur=sc.findIndex(b=>p>=b.a&&p<b.b),near=sc.findIndex(b=>p>=b.a&&p<b.a+.02&&b.i>0);const pi=v.interrupt>0&&near>=0?1-(p-sc[near].a)/.02:0,kind=near%3;
 x.save();const sh=(v.shake||0)*6*u+(pi&&kind==1?18*u*pi:0);if(sh)x.translate((Math.random()-.5)*sh,(Math.random()-.5)*sh);if(pi&&kind==0){x.translate(W/2,H/2);x.scale(1+.12*pi,1+.12*pi);x.translate(-W/2,-H/2)}
 bg(x,W,H,T,pr.visual);if(v.fog>0){const f=x.createLinearGradient(0,H*.5,0,H);f.addColorStop(0,'transparent');f.addColorStop(1,`rgba(180,170,200,${v.fog*.35})`);x.fillStyle=f;x.fillRect(0,0,W,H)}
 entity(x,pr,W/2,pr.fmt=='16:9'?H*.45:H*.34+Math.sin(T*.0006)*6,Math.min(W*.95,H*.62),Math.min(1,lvl*2.2),T);
 if(cur>=0)caption(x,W,H,sc[cur],p,pr,u);
 if(rt<3){x.textAlign='center';x.font=`900 ${68*u}px Impact,"Arial Black",sans-serif`;x.lineWidth=14*u;x.lineJoin='round';x.globalAlpha=rt>2.6?(3-rt)/.4:1;words(x,pr.hook,W*.84).forEach((s,i)=>{x.strokeStyle='#000';x.strokeText(s,W/2,H*.1+i*76*u);x.fillStyle='#fff';x.fillText(s,W/2,H*.1+i*76*u)});x.globalAlpha=1}
 if(p>.9){const q=(p-.9)/.1;x.fillStyle=`rgba(0,0,0,${Math.min(.65,q)})`;x.fillRect(0,0,W,H);x.globalAlpha=Math.min(1,q*1.5);x.textAlign='center';x.fillStyle='#e0a43a';x.font=`900 ${70*u}px Impact,sans-serif`;words(x,pr.loop?pr.hook:pr.cta,W*.8).forEach((s,i)=>x.fillText(s,W/2,H*.5+i*78*u));x.globalAlpha=1}
 x.restore();
 if(v.vhs>0&&(Math.random()<.04*v.vhs+(pi&&kind==2?.5:0))){x.fillStyle='rgba(255,255,255,.14)';x.fillRect(0,Math.random()*H,W,(4+Math.random()*14)*u);x.drawImage(x.canvas,(Math.random()-.5)*14*u*v.vhs,0)}
 if(v.glitch>0&&Math.random()<.02*v.glitch){x.fillStyle='rgba(255,0,60,.18)';x.fillRect(0,Math.random()*H,W,20*u)}
 if(v.grain>0){for(let i=0;i<400*v.grain;i++){x.fillStyle=`rgba(255,255,255,${Math.random()*.25})`;x.fillRect(Math.random()*W,Math.random()*H,2,2)}}
 if(v.scan>0){x.fillStyle=`rgba(0,0,0,${.22*v.scan})`;for(let y=0;y<H;y+=4)x.fillRect(0,y,W,1)}
 if(v.flicker>0&&Math.random()<.05*v.flicker){x.fillStyle='rgba(0,0,0,.35)';x.fillRect(0,0,W,H)}
 if(pi&&kind==2){x.fillStyle=`rgba(255,255,255,${.35*pi})`;x.fillRect(0,0,W,H)}
 if(v.vignette>0){const g=x.createRadialGradient(W/2,H/2,Math.min(W,H)*.3,W/2,H/2,Math.max(W,H)*.75);g.addColorStop(0,'transparent');g.addColorStop(1,`rgba(0,0,0,${.85*v.vignette})`);x.fillStyle=g;x.fillRect(0,0,W,H)}
 x.fillStyle='#e0a43a';x.fillRect(0,0,W*p,4*u)}
