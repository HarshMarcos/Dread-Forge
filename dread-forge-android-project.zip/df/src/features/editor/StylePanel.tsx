import type {Project} from '../../types';import {FACES,EYES,MOUTHS,VISUALS,CAPS,VFX_KEYS} from '../../data/catalog';import {Pills,Slider} from '../../components/ui';
export default function StylePanel({p,set}:{p:Project;set:(x:Partial<Project>)=>void}){const g=(t:string)=><span className="lbl">{t}</span>;
 return <div className="space-y-2">{g('Face')}<Pills o={FACES} v={p.face} set={face=>set({face})}/>{g('Eyes (mix and match)')}<Pills o={EYES} v={p.eyes} set={eyes=>set({eyes})}/>{g('Mouth')}<Pills o={MOUTHS} v={p.mouth} set={mouth=>set({mouth})}/>
  {g('Scene visual')}<Pills o={VISUALS} v={p.visual} set={visual=>set({visual})}/>{g('Caption style')}<Pills o={CAPS} v={p.caption} set={caption=>set({caption})}/>
  {g('Effects')}<div className="grid grid-cols-2 gap-x-3">{VFX_KEYS.map(k=><Slider key={k} l={k=='interrupt'?'pattern interrupts':k} v={p.vfx[k]||0} min={0} max={1} step={.05} set={n=>set({vfx:{...p.vfx,[k]:n}})}/>)}</div>
  <label className="flex gap-2 items-center mt-2"><input type="checkbox" checked={p.loop} onChange={e=>set({loop:e.target.checked})}/>Seamless loop: final frame returns to the hook</label></div>}
