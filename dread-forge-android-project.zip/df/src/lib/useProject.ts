import {useCallback,useEffect,useRef,useState} from 'react';import {db} from './db';import type {Project} from '../types';
export function useProject(id:string){const [p,setP]=useState<Project|null>(null),[saving,setSaving]=useState(false),h=useRef<Project[]>([]),f=useRef<Project[]>([]),t=useRef<number>(0);
 useEffect(()=>{db.get(id).then(x=>setP(x||null))},[id]);
 const save=(n:Project)=>{setSaving(true);clearTimeout(t.current);t.current=window.setTimeout(async()=>{await db.put(n);setSaving(false)},500)};
 const set=useCallback((patch:Partial<Project>|((x:Project)=>Partial<Project>))=>setP(c=>{if(!c)return c;h.current=[...h.current.slice(-59),c];f.current=[];const n={...c,...(typeof patch=='function'?patch(c):patch),updated:Date.now()};save(n);return n}),[]);
 const undo=()=>setP(c=>{const x=h.current.pop();if(!x||!c)return c;f.current.push(c);save(x);return x});
 const redo=()=>setP(c=>{const x=f.current.pop();if(!x||!c)return c;h.current.push(c);save(x);return x});
 return {p,set,undo,redo,saving}}
