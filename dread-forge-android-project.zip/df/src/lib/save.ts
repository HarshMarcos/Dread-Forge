import {Capacitor} from '@capacitor/core';import {Filesystem,Directory} from '@capacitor/filesystem';import {Share} from '@capacitor/share';
// Android WebView cannot download blobs, so on the phone we write the file and open the share sheet (Save to Files, WhatsApp, YouTube, etc.).
export async function saveBlob(b:Blob,name:string){
 if(Capacitor.isNativePlatform()){const data=await new Promise<string>(r=>{const f=new FileReader();f.onload=()=>r((f.result as string).split(',')[1]);f.readAsDataURL(b)});
  const w=await Filesystem.writeFile({path:name,data,directory:Directory.Cache});await Share.share({title:name,url:w.uri});return}
 const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;a.click()}
