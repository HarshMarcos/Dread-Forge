type L=(m:string)=>void;let ls:L[]=[];export const toast:L=m=>ls.forEach(l=>l(m));export const onToast=(l:L)=>{ls.push(l);return()=>{ls=ls.filter(x=>x!==l)}};
