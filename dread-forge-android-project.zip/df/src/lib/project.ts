import type {Project} from '../types';import {DEFAULT_FX,PRESETS} from '../features/voice/engine';import {story} from '../features/stories/forge';
export function forge(idea:string,o:Partial<Project>={}):Project{const g=o.genre||'Psychological horror',s=story(idea,{scary:60,mystery:60,realism:50,weird:40,twist:60},g);
 return {id:crypto.randomUUID(),title:s.hook.slice(0,48),idea,genre:g,fmt:'9:16',fps:30,res:720,hook:s.hook,script:s.lines.join('\n'),cta:s.cta,face:'shadow',eyes:'auto',mouth:'auto',visual:'hallway',caption:'viral',
  vfx:{grain:.5,scan:.5,vhs:.4,shake:.2,vignette:.8,flicker:.3,fog:.3,glitch:.4,interrupt:.7},fx:{...DEFAULT_FX,...PRESETS['Deep horror'].fx},fxOn:PRESETS['Deep horror'].on,loop:true,updated:Date.now(),hasAudio:false,...o}}
