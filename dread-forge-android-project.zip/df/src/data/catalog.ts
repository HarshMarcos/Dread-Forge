export const GENRES=['Psychological horror','Analog horror','Found footage','Paranormal','Urban legend','Mystery','Unsolved case','Backrooms','ARG','Cosmic horror','Creature horror','Rules horror','Chat horror','Emergency broadcast','Cursed object','Time loop','Doppelgänger','Based on a true story'];
export const FACES=['shadow','hollow','smiler','demon','pale','faceless'],EYES=['auto','dot','red','glow','empty'],MOUTHS=['auto','smile','open','line','none'];
export const VISUALS=['hallway','forest','cctv','static','void'],CAPS=['viral','typewriter','vhs','karaoke','alert'];
export const FORMATS:Record<string,string>={'9:16':'Shorts / Reels / TikTok','1:1':'Square','16:9':'YouTube','4:5':'Instagram feed'};
export const VFX_KEYS=['grain','scan','vhs','shake','vignette','flicker','fog','glitch','interrupt'];
// [name, genre, face, visual, caption, seed idea]
export const TEMPLATES:[string,string,string,string,string,string][]=[
['Rules Horror','Rules horror','hollow','hallway','viral','night shift rules at an empty hospital'],['Emergency Broadcast','Emergency broadcast','shadow','static','alert','a broadcast telling everyone to stay inside'],
['Found Footage','Found footage','faceless','cctv','vhs','a camera left running in a cabin'],['Text Message Horror','Chat horror','shadow','void','viral','a stranger texting from my own number'],
['CCTV Horror','Analog horror','pale','cctv','vhs','something standing in the parking garage footage'],['POV Horror','Psychological horror','smiler','hallway','karaoke','POV: someone is breathing behind you'],
['Unsolved Mystery','Unsolved case','shadow','forest','typewriter','a hiker who vanished near the old road'],['Analog Horror','Analog horror','pale','static','vhs','a lost children\'s program that shouldn\'t exist'],
['Cursed Object','Cursed object','demon','void','viral','a music box that plays when someone will die'],['Night Shift','Rules horror','hollow','hallway','viral','the 3 AM shift at a gas station'],
['Doppelgänger','Doppelgänger','pale','hallway','karaoke','my roommate came home twice tonight'],['3:07 AM','Paranormal','smiler','void','typewriter','knocking at my apartment door at 3:07 AM'],
['Missing Person','Unsolved case','faceless','forest','typewriter','a missing poster with my handwriting'],['Last Recording','Found footage','shadow','cctv','vhs','the last voice memo on a dead phone'],['Don\'t Look Behind You','Psychological horror','demon','hallway','viral','a mirror that shows the room one second late']];
