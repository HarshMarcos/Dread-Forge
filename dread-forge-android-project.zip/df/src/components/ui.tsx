import {useEffect,useState} from 'react';import {onToast} from '../lib/toast';
export const Toaster=()=>{const [m,s]=useState<string[]>([]);useEffect(()=>onToast(t=>{s(a=>[...a,t]);setTimeout(()=>s(a=>a.slice(1)),3200)}),[]);
 return <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2" role="status" aria-live="polite">{m.map((t,i)=><div key={i} className="card py-2 border-amber/60">{t}</div>)}</div>};
export const Slider=({l,v,min,max,step,on,set}:{l:string;v:number;min:number;max:number;step:number;on?:boolean;set:(n:number)=>void;tog?:()=>void})=>
 <label className="block"><span className="lbl">{l}: {Number(v).toFixed(2)}</span><input type="range" className="w-full accent-amber" min={min} max={max} step={step} value={v} onChange={e=>set(+e.target.value)}/></label>;
export const Pills=({o,v,set}:{o:string[];v:string;set:(s:string)=>void})=><div className="flex flex-wrap gap-1.5">{o.map(k=><button key={k} className={'btn '+(v==k?'on':'')} onClick={()=>set(k)}>{k}</button>)}</div>;
