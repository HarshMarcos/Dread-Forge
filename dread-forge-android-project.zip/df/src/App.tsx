import {HashRouter,Route,Routes} from 'react-router-dom';import Dashboard from './pages/Dashboard';import Studio from './pages/Studio';import {Toaster} from './components/ui';
export default function App(){return <HashRouter><Routes><Route path="/" element={<Dashboard/>}/><Route path="/studio/:id" element={<Studio/>}/></Routes><Toaster/></HashRouter>}
