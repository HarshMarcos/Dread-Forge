export type Fmt='9:16'|'1:1'|'16:9'|'4:5';
export type Num=Record<string,number>;
export interface Project{id:string;title:string;idea:string;genre:string;fmt:Fmt;fps:number;res:number;hook:string;script:string;cta:string;
 face:string;eyes:string;mouth:string;visual:string;caption:string;vfx:Num;fx:Num;fxOn:Record<string,boolean>;loop:boolean;updated:number;hasAudio:boolean}
export interface Controls{scary:number;mystery:number;realism:number;weird:number;twist:number}
